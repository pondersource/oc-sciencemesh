<ul class="with-icon">
    <li><a class="icon-comment" style="padding-left:34px" href="generate">Generate ScienceMesh Invite</a></li>
    <li><a class="icon-mail" style="padding-left:34px" href="accept">Accept ScienceMesh Invite</a></li>
    <li><a class="icon-contacts-dark" style="padding-left:34px" href="contacts">ScienceMesh Contacts</a></li>
</ul>